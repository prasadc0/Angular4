import { PopUpDirectiveDirective } from './pop-up-directive.directive';

describe('PopUpDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new PopUpDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
