import { Type } from '@angular/core';

export interface AdComponent {
  data: any;
}