export class Hero {

	constructor(
		public  firstname: string,
		public lastname : string ,
		public age : number,
		public altergo? : string
		){
		 
	}

}
