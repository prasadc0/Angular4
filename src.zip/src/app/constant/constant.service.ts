import { Injectable } from '@angular/core';

@Injectable()
export class ConstantService {
	 
  constructor() { }
 constUrl='http://localhost:7001/RSSShipping/shipping/outbound/281';
}
