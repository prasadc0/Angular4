import { Component } from '@angular/core';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {MatTableDataSource} from '@angular/material';
import {TranslateService} from 'ng2-translate';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { customPopUp } from './CustomPopUp';



export interface ConfirmModel {
  title:string;
  message:string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})



export class AppComponent   {
	
	 

constructor(translate: TranslateService,private dialogService: DialogService ) { 
	
	 

  	translate.setDefaultLang('en');
 
          
        translate.use('en');
    }

    showConfirm() {
            let disposable = this.dialogService.addDialog(customPopUp, {title:'TWO BUTTON',message:'Click on the button to confirm'})
                .subscribe((isConfirmed)=>{
                    //We get dialog result
                    if(isConfirmed) {
                       console.log(isConfirmed , 'is the value');
                    }
                    else {
                       console.log(isConfirmed , 'is the value');
                        
                    }
                });
            //We can close dialog calling disposable.unsubscribe();
            //If dialog was not closed manually close it by timeout
            setTimeout(()=>{
                disposable.unsubscribe();
            },100000000);
        }; 
  public OPenbreadcrumb = false;
  title = 'Shipping and Receiving';
ModuleName = 'Shipping and Receiving';
  
}

 